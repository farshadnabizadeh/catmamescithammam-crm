<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 table-responsive">
            <nav aria-label="breadcrumb" class="mt-3">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item home-page"><a href="<?php echo e(url('home')); ?>">Arayüz</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Rezervasyonlar</li>
                </ol>
            </nav>
            <div class="card p-3 mt-3">
                <div class="card-title">
                    <div class="row">
                        <div class="col-lg-6">
                            <h2>Rezervasyonlar</h2>
                        </div>
                        <div class="col-lg-6">
                            <a href="<?php echo e(url('/definitions/reservations/create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus" aria-hidden="true"></i> Yeni Rezervasyon</a>
                        </div>
                    </div>
                </div>
                <div class="dt-responsive table-responsive">
                    <?php echo $html->table(); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php echo $html->scripts(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/reservations/reservations_list.blade.php ENDPATH**/ ?>