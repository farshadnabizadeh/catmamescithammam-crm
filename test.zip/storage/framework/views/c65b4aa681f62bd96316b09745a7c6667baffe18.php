<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
   <div class="row mt-3">
      <div class="col-lg-12">
         <div class="card">
            <div class="card-body">
               <form action="" method="GET">
                  <div class="row pb-3">
                     <div class="col-lg-6">
                        <label for="startDate">Başlangıç Tarihi</label>
                        <input type="text" class="form-control datepicker" id="startDate" name="startDate" placeholder="Başlangıç Tarihi" value="<?php echo e($start); ?>" autocomplete="off" required>
                     </div>
                     <div class="col-lg-6">
                        <label for="endDate">Bitiş Tarihi</label>
                        <input type="text" class="form-control datepicker" id="endDate" name="endDate" placeholder="Bitiş Tarihi" autocomplete="off" value="<?php echo e($end); ?>" required>
                     </div>
                     <div class="col-lg-12">
                        <button class="btn btn-success mt-3 float-right" type="submit">Raporu Al</button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>

   <div class="row">
      <div class="col-lg-12">
         <div class="card p-3">
            <div class="card-title">
               <h2>Ciro Raporu | <?php echo e($start); ?> & <?php echo e($end); ?></h2>
               <hr>
            </div>
            <div class="card-body">
               <p>CASH TL: <?php echo e($cashTl); ?></p>
               <p>CASH EURO: <?php echo e($cashEur); ?></p>
               <p>CASH DOLAR: <?php echo e($cashUsd); ?></p>
               <p>CASH POUND: <?php echo e($cashPound); ?></p>
               <hr>
               <p>YKB KK TL: <?php echo e($ykbTl); ?></p>
               <p>ZİRAAT KK TL: <?php echo e($ziraatTl); ?></p>
               <p>ZİRAAT KK EURO: <?php echo e($ziraatEuro); ?></p>
               <p>ZİRAAT KK DOLAR: <?php echo e($ziraatDolar); ?></p>
            </div>
         </div>
      </div>
   </div>
   <div class="container-xxl flex-grow-1 container-p-y">
      

   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/reports/payment_report.blade.php ENDPATH**/ ?>