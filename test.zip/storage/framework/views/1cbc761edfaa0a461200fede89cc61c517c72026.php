<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-danger mt-3" onclick="previousPage();"><i class="fa fa-chevron-left" aria-hidden="true"></i> Önceki Sayfa</button>
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h3>Durumu Güncelle</h3>
                    <p class="float-right last-user">İşlem Yapan Son Kullanıcı: <?php echo e($form_status->user->name); ?></p>
                </div>
                <form action="<?php echo e(url('/definitions/formstatuses/update/'.$form_status->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="statusName">Durum Adı</label>
                                <input type="text" class="form-control" id="statusName" name="statusName" placeholder="Durum Adı" value="<?php echo e($form_status->name); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="statusColor">Durum Rengi</label>
                                <input type="text" class="form-control" id="colorpicker" name="statusColor" placeholder="Durum Rengi" value="<?php echo e($form_status->color); ?>">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-5 float-right">Güncelle <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/formstatuses/edit_form_statuses.blade.php ENDPATH**/ ?>