<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 table-responsive">
            <button class="btn btn-primary mt-3" onclick="previousPage();"><i class="fa fa-chevron-left" aria-hidden="true"></i> Önceki Sayfa</button>
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <div class="row">
                        <div class="col-md-6">
                            <h2><?php echo e($tableTitle); ?></h2>
                        </div>
                        <div class="col-md-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create treatmentplan')): ?>
                            <a href="<?php echo e(url('/definitions/treatmentplans/create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus" aria-hidden="true"></i> New Request</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="dt-responsive table-responsive">
                    <table class="table table-striped table-bordered nowrap dataTable" id="dataTable">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">Operation</th>
                                <th scope="col">ID</th>
                                <th scope="col">Rezervasyon Tarihi</th>
                                <th scope="col">Rezervasyon Saati</th>
                                <th scope="col">Müşteri Adı</th>
                                <th scope="col">Toplam Müşteri</th>
                                <th scope="col">Hizmet Bedeli</th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $listAllByDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listAllByDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-primary dropdown-toggle action-btn" type="button" data-toggle="dropdown">İşlem <span class="caret"></span></button>
                                        <ul class="dropdown-menu">
                                            
                                            <li><a href="<?php echo e(url('/definitions/reservations/edit/'.$listAllByDate->tId)); ?>" class="btn btn-info edit-btn"><i class="fa fa-pencil-square-o"></i> Güncelle</a></li>
                                            <li><a href="<?php echo e(url('/definitions/reservations/download/'.$listAllByDate->tId.'?lang=en')); ?>" class="btn btn-success edit-btn"><i class="fa fa-download"></i> İndir</a></li>
                                        </ul>
                                    </div>
                                </td>
                                <td><?php echo e(date('ymd', strtotime($listAllByDate->date))); ?><?php echo e($listAllByDate->customer_id); ?><?php echo e($listAllByDate->id); ?></td>
                                <td> <?php echo e(date('d-m-Y', strtotime($listAllByDate->reservation_date))); ?></td>
                                <td><?php echo e($listAllByDate->reservation_time); ?></td>
                                <td><a href="<?php echo e(url('/definitions/customers/edit/'.$listAllByDate->customer_id)); ?>"><?php echo e($listAllByDate->Cname); ?></a></td>
                                <td><?php echo e($listAllByDate->total_customer); ?></td>
                                <td><?php echo e($listAllByDate->service_cost); ?> <?php echo e($listAllByDate->service_currency); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
               </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/reservations/all_reservation.blade.php ENDPATH**/ ?>