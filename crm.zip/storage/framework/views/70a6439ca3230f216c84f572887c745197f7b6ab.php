

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-danger mt-3" onclick="previousPage();"><i class="fa fa-chevron-left" aria-hidden="true"></i> Previous Page</button>
            <div class="card p-5 mt-3">
                <div class="card-title">
                    <h2>Edit Reservation</h2>
                    <p class="float-right last-user">Last Operation User: <?php echo e($reservation->user->name); ?></p>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <h2 class="mt-5 sub-table-title">Customers</h2>
                    </div>
                    <div class="col-lg-6">
                        <button class="btn btn-danger float-right mt-5" data-toggle="modal" data-target="#addCustomer"><i class="fa fa-plus" aria-hidden="true"></i> Add New Customer</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 dt-responsive table-responsive mb-5">
                        <table class="table table-striped table-bordered nowrap dataTable" id="tableData">
                            <tr>
                                <th>Customer Name</th>
                                <th>Customer Surname</th>
                                <th>Customer Phone</th>
                                <th>Customer Country</th>
                                <th>Customer Email</th>
                            </tr>
                            <tbody>
                                <?php $__currentLoopData = $reservation->subCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCustomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($subCustomer->customer_name); ?></td>
                                    <td><?php echo e($subCustomer->customer_surname); ?></td>
                                    <td><?php echo e($subCustomer->customer_phone); ?></td>
                                    <td><?php echo e($subCustomer->customer_country); ?></td>
                                    <td><?php echo e($subCustomer->customer_email); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <form action="<?php echo e(url('/definitions/reservations/update/'.$reservation->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="arrivalDate">Reservation Date</label>
                                <input type="text" class="form-control datepicker" id="arrivalDate" name="arrivalDate" placeholder="Enter Reservation Date" value="<?php echo e($reservation->reservation_date); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="reservationTime">Reservation Time</label>
                                <input type="text" class="form-control" id="arrivalTime" name="arrivalTime" placeholder="Enter Reservation Time" maxlength="5" onkeypress="timeFormat(this)" value="<?php echo e($reservation->reservation_time); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="totalCustomer">Total Customer</label>
                                <input type="number" class="form-control" id="totalCustomer" name="totalCustomer" placeholder="Enter Total Customer" value="<?php echo e($reservation->total_customer); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="serviceId">Service</label>
                                <select id="serviceId" name="serviceId" class="form-control" required>
                                    <option value="<?php echo e($reservation->service->id); ?>"><?php echo e($reservation->service->service_name); ?></option>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($service->id); ?>"><?php echo e($service->service_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="serviceCurrency">Service Currency</label>
                                <select id="customerSobId" name="serviceCurrency" class="form-control" required>
                                    <option value="<?php echo e($reservation->service_currency); ?>" @selected(true)><?php echo e($reservation->service_currency); ?></option>
                                    <option value="EUR">EURO</option>
                                    <option value="USD">USD</option>
                                    <option value="GBP">GBP</option>
                                    <option value="TL">TL</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="serviceCost">Service Cost</label>
                                <input type="number" class="form-control" id="serviceCost" name="serviceCost" placeholder="Enter Service Cost" value="<?php echo e($reservation->service_cost); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="serviceComission">Service Comission</label>
                                <input type="number" class="form-control" id="serviceComission" name="serviceComission" placeholder="Enter Service Comission" value="<?php echo e($reservation->service_comission); ?>">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="therapistId">Therapist</label>
                                <select id="therapistId" name="therapistId" class="form-control">
                                    <option value="<?php echo e($reservation->therapist->id); ?>" @selected(true)><?php echo e($reservation->therapist->therapist_name); ?></option>
                                    <?php $__currentLoopData = $therapists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $therapist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($therapist->id); ?>"><?php echo e($therapist->therapist_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-5 float-right">Update <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addCustomer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add New Customer</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="reservation_id" value="<?php echo e($reservation->id); ?>">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="customerId">Customer</label>
                            <select class="form-control" id="customerId" name="treatmentId" required>
                                <option></option>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->customer_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
               </div>
               <button type="button" class="btn btn-success float-right" id="saveCustomerReservation">Save <i class="fa fa-check" aria-hidden="true"></i></button>
            </form>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\works\catmamescithammam\crm\resources\views/admin/reservations/edit_reservation.blade.php ENDPATH**/ ?>