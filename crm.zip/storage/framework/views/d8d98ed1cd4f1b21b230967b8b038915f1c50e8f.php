

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-danger mt-3" onclick="previousPage();"><i class="fa fa-chevron-left" aria-hidden="true"></i> Previous Page</button>
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Edit Therapist</h2>
                    <p class="float-right last-user">Last Operation User: <?php echo e($therapist->user->name); ?></p>
                </div>
                <form action="<?php echo e(url('/definitions/therapists/update/'.$therapist->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="therapistName">Therapist Name</label>
                                <input type="text" class="form-control" id="therapistName" name="therapistName" placeholder="Enter Therapist Name" value="<?php echo e($therapist->therapist_name); ?>" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary float-right">Update <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\works\catmamescithammam\crm\resources\views/admin/therapists/edit_therapist.blade.php ENDPATH**/ ?>