

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-danger mt-3" onclick="previousPage();"><i class="fa fa-chevron-left" aria-hidden="true"></i> Previous Page</button>
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Edit Source</h2>
                    <p class="float-right last-user">Last Operation User: <?php echo e($source->user->name); ?></p>
                </div>
                <form action="<?php echo e(url('/definitions/sources/update/'.$source->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="sourceName">Source Name</label>
                                <input type="text" class="form-control" id="sourceName" name="sourceName" placeholder="Enter Source Name" value="<?php echo e($source->source_name); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="sourceColor">Source Color</label>
                                <input type="text" class="form-control" id="colorpicker" name="sourceColor" placeholder="Enter Source Color" value="<?php echo e($source->source_color); ?>" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-5 float-right">Update <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\works\catmamescithammam\crm\resources\views/admin/sources/edit_source.blade.php ENDPATH**/ ?>